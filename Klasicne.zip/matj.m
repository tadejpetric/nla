function M=MATJ(X)

% MATJ(X) vrne iteracijsko matriko Jacobijeve iteracijske metode za matriko X.

d=diag(diag(X));
lu=X-d;
M=-inv(d)*lu;
