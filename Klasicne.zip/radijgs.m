function Y=radijgs(X)

% RADIJGS(X) vrne spektralni radij Gauss-Seidelove iteracijske metode za matriko X

m=matgs(X);
Y=norm(eig(m),inf);
