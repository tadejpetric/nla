function Y=radijj(X)

% RADIJJ(X) vrne spektralni radij Jacobijeve iteracijske metode za matriko X

m=matj(X);
Y=norm(eig(m),inf);
