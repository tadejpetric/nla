function M=MATSOR(X,w)

% MATSOR(X,w) vrne iteracijsko matriko SOR iteracijske metode s parametrom w za matriko X.

d=diag(diag(X));
l=tril(X,-1);
u=triu(X,1);
M=-inv(w*l+d)*((1-w)*d-w*u);
