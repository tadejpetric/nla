function [x, error, iter, flag]  = gs(A, x, b, max_it, tol)

[x, error, iter, flag]  = sor(A, x, b, 1, max_it, tol);