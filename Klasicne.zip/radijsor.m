function Y=radijsor(X,w)

% RADIJSOR(X) vrne spektralni radij SOR iteracijske metode s parametrom w za matriko X

mm=matsor(X,w);
Y=norm(eig(mm),inf);
