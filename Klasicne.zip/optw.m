function y=optw(A)

y=2/(1+sqrt(1-radijj(A)^2));