function grafsor(X,a,b)

% GRAFSOR(X,a,b) narise graf spektralnega radija pri SOR metodi za matriko X
% v odvisnosti od w na intervalu [a,b] za w.

h=(b-a)/25;
for j=1:26
  w(j)=a+(j-1)*h;
  y(j)=radijsor(X,w(j));
end

plot(w,y);		
