function M=MATGS(X)

% MATGS(X) vrne iteracijsko matriko Gauss-Seidelove iteracijske metode za matriko X.

d=diag(diag(X));
l=tril(X,-1);
u=triu(X,1);
M=-inv(l+d)*u;
